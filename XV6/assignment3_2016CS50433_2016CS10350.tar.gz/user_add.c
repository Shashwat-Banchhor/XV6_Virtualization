#include "types.h"
#include "user.h"
#include "date.h"
int
main(int argc, char *argv[])
{
	int answer = add(3,4);
	printf(1,"The answer is : %d \n",answer);
	exit();
}