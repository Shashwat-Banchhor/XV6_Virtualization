#include "types.h"
#include "user.h"
#include "date.h"
int
main(int argc, char *argv[])
{
	ps();
	// printf(1,"The answer is : %d \n",answer);
	exit();
}